# EarthSignal: Project Overview

| | |
|---|---|
| **Document** | Project overview and plan |
| **Based on** | Baseline Product Specification v1.0 (2026-10-27) |
| **Last updated** | 2026-11-03 |
| **Status** | Early development. Core NDVI calculation is complete and tested. |
| **Pilot city** | Chandigarh |

---

## Contents

1. [Vision](#1-vision)
2. [Goals and non-goals](#2-goals-and-non-goals)
3. [Audience and user journeys](#3-audience-and-user-journeys)
4. [Product experience](#4-product-experience)
5. [Data](#5-data)
6. [Methodology](#6-methodology)
7. [Model evaluation](#7-model-evaluation)
8. [Architecture](#8-architecture)
9. [Scope: the five MVPs](#9-scope-the-five-mvps)
10. [Roadmap](#10-roadmap)
11. [Acceptance criteria](#11-acceptance-criteria)
12. [Risks and mitigations](#12-risks-and-mitigations)
13. [Repository layout](#13-repository-layout)
14. [First milestone and definition of done](#14-first-milestone-and-definition-of-done)

---

## 1. Vision

EarthSignal is an interactive environmental intelligence platform for exploring Indian cities as evolving digital worlds. Users discover environmental changes, test carefully defined scenarios, and inspect the evidence behind every result.

A navigable 3D Earth transitions into city terrain, satellite imagery, environmental layers and neighbourhood-level analysis.

**Core principle:** the globe should make users curious; scientifically trustworthy results should make them stay.

**Geographic scope:** the architecture is India-wide, with one pilot city validated first. Chandigarh is the pilot, subject to data availability, boundary validation, historical coverage and processing feasibility.

**Core outcomes:** investigate changes, predict future trends where valid, and compare carefully defined hypothetical interventions.

---

## 2. Goals and non-goals

### Goals

| ID | Goal |
|---|---|
| G1 | Make environmental change understandable through interactive exploration. |
| G2 | Compare places and years using traceable data. |
| G3 | Detect unusual changes without confusing statistical anomalies with proven environmental damage. |
| G4 | Provide forecasts and hypothetical scenarios with uncertainty clearly communicated. |
| G5 | Make analysis inspectable and reproducible. |
| G6 | Demonstrate serious engineering and data-science skills in a portfolio-quality application. |

### Non-goals

| ID | Non-goal |
|---|---|
| N1 | Not a replacement for Google Maps or a live navigation service. |
| N2 | Not a real-time digital twin of every building or environmental process. |
| N3 | Does not prove causation from correlation alone. |
| N4 | Not an AI chatbot that invents environmental facts. |
| N5 | Does not promise exact knowledge of a city's future. |

---

## 3. Audience and user journeys

**Primary audience:** everyone, including curious citizens, students, researchers, environmental scientists, urban planners, NGOs and decision-makers.

| Persona | Journey |
|---|---|
| **Curious citizen** | Open EarthSignal, choose a city, move through time, inspect vegetation change, review evidence, share a visual story. |
| **Student or researcher** | Choose a variable and period, compare areas, inspect coverage and methods, run an analysis, export a reproducible report. |
| **Planner or NGO analyst** | Select city boundaries, find unusual heat or vegetation patterns, compare relevant context, investigate possible explanations, create a briefing. |
| **AI-assisted investigator** | Ask a question. The backend queries real processed datasets, and the assistant presents maps, calculations, sources and limitations. |

---

## 4. Product experience

### Four levels

| Level | Name | Contents |
|:--:|---|---|
| 1 | Earth | Immersive 3D globe, city search, environmental highlights |
| 2 | City | Satellite imagery, boundaries, environmental map layers |
| 3 | Investigation | Timelines, comparisons, anomalies, evidence |
| 4 | Experiment | Validated models, scenario assumptions, uncertainty |

### Interface

| Element | Behaviour |
|---|---|
| Main canvas | The globe or interactive city map occupies most of the screen. |
| Navigation | Explore, Compare, Discover, Forecast, Stories. |
| Context panel | Opens when a user selects a place, layer or finding. |
| Time control | A timeline that marks available observations and missing periods. |
| Evidence drawer | Shows sources, dates, resolution, methodology, quality flags and uncertainty. |
| AI investigator | A contextual assistant that queries the selected area's actual data. |

### Visual direction

Immersive scientific cartography: natural terrain colours, atmospheric depth, scientific labels, distinctive typography, restrained accents and purposeful animation.

**Animation principle:** motion must explain a change, establish context or guide attention. It must not obscure scientific information.

### Website and application

The website (an animated landing page showcasing genuine findings) and the application (globe, city map, timelines, analysis and evidence) share one codebase and one product identity. Stories link directly to the relevant map state and evidence. The application is built first, and the website follows.

---

## 5. Data

### Candidate sources

| Variable | Candidate source | Notes |
|---|---|---|
| Satellite vegetation | Copernicus Sentinel-2 | Vegetation indices at relatively fine resolution. Band resolutions vary. |
| Historical surface temperature | USGS Landsat Collection 2 | Decades of history. Scene quality, sensor differences and cloud cover need screening. |
| Weather and climate | ERA5 and ERA5-Land | Atmospheric context at a coarser resolution than satellite layers. |
| Air quality | CPCB monitoring data | Validate historical coverage, station quality, access and permissions. |
| City boundaries | Official municipal or government geospatial sources | OpenStreetMap may supplement if licence and suitability are checked. |

### Known limitations

- **Non-uniform history.** There is no promise of a uniform 20-year record for every variable. Sentinel-2 starts in 2017, and Landsat, ERA5 and air-quality records have different coverage and resolutions.
- **Spatial resolution.** Neighbourhood-level precision is never implied for coarse weather grids or sparse air-quality stations. The actual measurement resolution is always displayed.

### Governance

- **Dataset catalogue:** for every dataset, record source, licence, temporal coverage, spatial resolution, processing history, quality flags and update policy.
- **Provenance:** for every run, record source version, processing parameters, code version and processing date.

### Processing pipeline

```mermaid
flowchart LR
    A["Source data"] --> B["1. Ingest and quality checks"]
    B --> C["2. Standardise units, dates, coordinates"]
    C --> D["3. Apply cloud, missing-data and quality masks"]
    D --> E["4. Aggregate in space and time"]
    E --> F[("5. Versioned raster and vector datasets")]
    F --> G["6. Serve maps, charts, comparisons, forecasts"]
    G --> H["7. Attach evidence and sources to each finding"]
```

---

## 6. Methodology

| Topic | Approach | Limitation to state |
|---|---|---|
| **Vegetation** | NDVI = (NIR - Red) / (NIR + Red) from suitable reflectance bands. Mask clouds and shadows, aggregate comparable seasonal or annual periods, report valid-pixel coverage. | NDVI measures vegetation greenness. It is not a direct measure of tree count, biodiversity or total green space. |
| **Surface temperature** | Quality-screened Landsat surface-temperature products. Apply scale factors and masks, compare consistent seasonal windows, report units and observation counts. | Land-surface temperature is not air temperature, nor the temperature people experience. |
| **Neighbourhood comparison** | Compare consistent geographic units and periods. Calculate median NDVI and temperature, changes, valid-pixel coverage, observation counts, weather context and available station readings. | Only compare like with like. |
| **Missing data** | Never present areas with missing observations as healthy or unchanged. Expose gaps and quality. | |
| **Anomaly detection** | Start with explainable statistics and robust seasonal baselines. A z-score may be used where its assumptions fit. Consider autocorrelation, skew, multiple testing and minimum sample counts. | An anomaly is unusual relative to a defined baseline. It does not indicate harm or establish a cause. |
| **Forecasting** | Train on past data and evaluate on future periods using chronological holdouts and rolling-origin backtesting. | Usefulness is not claimed unless the model passes its criteria. |
| **Scenario analysis** | Keep hypothetical interventions separate from forecasts. Define changed variables, fixed assumptions, applicability and evidence before interpreting outputs. | Modelled outcomes are not measured future facts. |

---

## 7. Model evaluation

| Principle | Requirement |
|---|---|
| Baseline | Compare every model against a simple baseline. |
| Leakage prevention | Split data chronologically so future information never enters training. |
| Spatial generalisation | Where feasible, evaluate on unseen geographic areas as well as held-out periods. |
| Metrics | Use suitable metrics such as MAE and RMSE. Evaluate uncertainty-interval calibration and coverage. |
| Reproducibility | Record training data, features, model version, parameters and limitations. |
| Abstention | Do not issue a prediction when data quality or model applicability is inadequate. |

---

## 8. Architecture

| Layer | Choice |
|---|---|
| Frontend | React + TypeScript + Vite |
| Globe | CesiumJS or an equivalent engine, with MapLibre considered for 2D mapping |
| Custom visual effects | Three.js and carefully selected shaders where they add value |
| Charts | Plotly or a suitable custom charting library |
| Backend | Python + FastAPI |
| Geospatial processing | Rasterio, GeoPandas, xarray and NumPy, chosen to suit the dataset formats |
| Machine learning | scikit-learn first, for baselines, anomaly detection and forecasting experiments |
| Database | PostgreSQL + PostGIS for boundaries, metadata and spatial queries |
| Raster storage | Cloud-Optimized GeoTIFFs and static files initially |
| Testing | pytest, plus frontend component and browser tests |
| Deployment | Static frontend hosting and a suitable Python backend host. Verify free-tier quotas and terms. |
| AI assistant | Optional language model, added later. Every numerical claim must come from an explicit, testable backend query and validated results. |

---

## 9. Scope: the five MVPs

| MVP | Name | Scope |
|:--:|---|---|
| 1 | Virtual Earth | Navigable globe, city search, transition to the city map, basic geographic layers, accessible 2D fallback |
| 2 | Environmental time travel | Select available periods, compare vegetation and surface temperature, inspect gaps, view city-wide trends |
| 3 | Discover and compare | Compare areas, rank defined change metrics, show anomaly highlights, inspect evidence |
| 4 | Predictive experiment | One well-defined forecasting task, a baseline, chronological evaluation, uncertainty-aware results |
| 5 | Evidence and storytelling | Source panel, one guided story, report export, data-grounded assistant |

**Deliberately deferred:** real-time global monitoring, complete histories for every Indian city, building-level temperature, unsupported causal claims, complex multi-agent AI, social features and expensive cloud infrastructure.

---

## 10. Roadmap

| Phase | Name | Estimate | Focus | Exit criterion |
|:--:|---|---|---|---|
| 0 | Research | 1 to 2 weeks | Validate city boundary, data licences, time coverage, source samples and the first scientific question | Sample processing succeeds |
| 1 | Data engine | 3 to 5 weeks | Ingestion, masks, summaries, aggregation, metadata, reproducible processing | Validated outputs and automated tests |
| 2 | Virtual Earth UI | 3 to 5 weeks | Globe, city transition, map layers, timeline, responsive panels | Actual processed data is explorable |
| 3 | Discovery | 2 to 4 weeks | Comparisons, anomalies, evidence views, one story | A user can reproduce and understand a finding |
| 4 | Prediction | 3 to 5 weeks | Evaluate one forecasting model. Add scenario comparisons only if assumptions and data support them | Model evaluated against a baseline |
| 5 | Release | 2 to 4 weeks | Polish animations, evidence-backed AI, reports, deployment, documentation | Clean, reproducible deployment |

**Total:** approximately 14 to 25 weeks as a planning range, to be re-estimated after Phase 0. Because this project is also a learning journey, it may take longer.

### Progress so far

- [x] Specification written and baselined
- [x] Repository created, with Python environment and project structure
- [x] NDVI calculation that keeps invalid pixels as missing (NaN), with unit tests
- [ ] FastAPI backend (next)
- [ ] Phase 0 research tasks

---

## 11. Acceptance criteria

| Area | Criterion |
|---|---|
| Globe and map | The globe loads, city navigation works, and a 2D fallback is available. |
| Timeline | Changing the period updates data, charts and metadata consistently. |
| Vegetation | NDVI is calculated from valid reflectance data and checked against a trusted reference calculation. |
| Temperature | Scale factors are applied correctly, invalid observations are masked, and units are explicit. |
| Comparison | Areas use consistent definitions, periods and quality rules. Missing data is disclosed. |
| Anomaly | Baseline, threshold and method are documented. Insufficient-data cases are handled. |
| Forecast | Chronological holdouts and a defined baseline are used. Usefulness is not claimed without passing criteria. |
| Scenario | Assumptions and limitations are visible. Modelled outcomes are not presented as measured future facts. |
| Evidence | Every finding identifies its source, date range, processing method and limitations. |
| AI | Numerical claims are grounded in application queries or validated results. Unsupported answers acknowledge missing evidence. |
| Reports | Exports include charts, units, periods, sources and methodology. |
| Accessibility | Keyboard navigation, readable contrast and reduced-motion settings are supported. |
| Performance | Map interaction and queries meet targets on an agreed reference device and dataset. |
| Deployment | A clean deployment is reproducible from documented instructions, with no local-file dependencies or exposed secrets. |

### Performance targets

- **Initial interactivity:** about 3 seconds on reasonable broadband, excluding unusually slow external data services.
- **Cached queries:** typical cached pilot-dataset analysis queries within 2 seconds.
- **Testing:** core calculations have automated tests, and documented scientific checks pass before release.

---

## 12. Risks and mitigations

| Risk | Mitigation |
|---|---|
| **Scope creep** | Prove one complete city workflow before expanding. |
| **Data gaps** (cloud cover, seasonality, sensor changes, monitoring gaps) | Masks, comparable periods, metadata, sensitivity checks and missing-data indicators. |
| **Model reliability** | Baselines, holdouts, uncertainty, stated limitations and abstention. |
| **Visual complexity** | Keep motion purposeful, retain a performant 2D alternative, support reduced motion. |
| **Free infrastructure limits** | Cache processed outputs, avoid per-interaction satellite processing, verify quotas, and keep the core usable without paid AI. |

---

## 13. Repository layout

| Folder | Purpose | Status |
|---|---|:--:|
| `data/` | Dataset catalogue, licences, provenance, small permitted sample files | Created |
| `pipeline/` | Reproducible ingestion and processing jobs | Created |
| `tests/` | Scientific calculations, data quality, API and UI tests | Created |
| `docs/` | Architecture decisions, data dictionary, methodology, limitations, setup | Created |
| `assets/` | Illustrations used in the README | Created |
| `backend/` | API endpoints, spatial queries, analysis services | Next |
| `analysis/` | Exploratory analysis and scientific validation | Planned |
| `models/` | Training, evaluation, versioned model metadata | Planned |
| `frontend/` | Globe, map, controls and evidence panels | Planned |

### Portfolio documentation

To show real engineering skill, the project documents the problem, data validation, experiments (including failures), model choices, baseline comparisons, engineering decisions, uncertainties and remaining limitations.

---

## 14. First milestone and definition of done

### First milestone: pilot-city feasibility report

Confirm the city boundary, satellite coverage, valid observations, weather data, air-quality station coverage, the first reliable analysis, and processing and hosting needs.

**Go/no-go rule:** the full globe build does not begin until a sample dataset can be processed and the pilot's first scientific question is demonstrably feasible.

### Definition of done for the first major release

A user can open the deployed site, navigate to the pilot city, explore real historical data, compare areas and years, investigate a change, inspect evidence, and examine one properly evaluated prediction.

---

> **North star:** build a virtual world that looks extraordinary because the science inside it is extraordinary, not because animation is hiding an ordinary project.