import { useMemo, useState } from 'react';

type Layer = 'vegetation' | 'temperature' | 'air';
type Place = { name: string; region: string; x: number; y: number; note: string };

const places: Place[] = [
  { name: 'Chandigarh', region: 'Pilot city · North India', x: 49, y: 26, note: 'Our first study area. The NDVI calculation pipeline is ready; satellite observations still need to be sourced and processed.' },
  { name: 'Delhi', region: 'National Capital Territory', x: 52, y: 31, note: 'A future comparison area. No environmental measurements have been loaded yet.' },
  { name: 'Jaipur', region: 'Rajasthan', x: 42, y: 39, note: 'A future comparison area. No environmental measurements have been loaded yet.' },
  { name: 'Mumbai', region: 'Maharashtra', x: 30, y: 65, note: 'A future comparison area. No environmental measurements have been loaded yet.' },
  { name: 'Bengaluru', region: 'Karnataka', x: 51, y: 78, note: 'A future comparison area. No environmental measurements have been loaded yet.' },
  { name: 'Kolkata', region: 'West Bengal', x: 77, y: 49, note: 'A future comparison area. No environmental measurements have been loaded yet.' },
];

const layerInfo: Record<Layer, { label: string; short: string; detail: string; status: string }> = {
  vegetation: { label: 'Vegetation', short: 'NDVI', detail: 'NDVI estimates vegetation greenness from near-infrared and red reflectance. It does not directly measure tree count or biodiversity.', status: 'Calculation ready · imagery not loaded' },
  temperature: { label: 'Surface heat', short: 'LST', detail: 'Land-surface temperature is measured from satellite observations. It is not the same as air temperature or the temperature people feel.', status: 'Planned · no observations loaded' },
  air: { label: 'Air quality', short: 'AQI', detail: 'Air-quality readings depend on monitoring-station coverage, measurement methods and reporting periods.', status: 'Planned · no station data loaded' },
};

function Arrow({ diagonal = false }: { diagonal?: boolean }) {
  return <span aria-hidden="true">{diagonal ? '↗' : '→'}</span>;
}

function IndiaMap({ selected, onSelect, layer }: { selected: string; onSelect: (name: string) => void; layer: Layer }) {
  return <div className={`map-art map-${layer}`}>
    <div className="map-grid" />
    <svg className="india-shape" viewBox="0 0 420 480" role="img" aria-label="Illustrated schematic map of India with selectable city markers">
      <defs>
        <linearGradient id="land" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stopColor="#d8bd83"/><stop offset="1" stopColor="#8caa82"/></linearGradient>
        <filter id="soft"><feGaussianBlur stdDeviation="8"/></filter>
      </defs>
      <path d="M93 44 L145 27 185 43 219 35 247 62 285 68 306 101 337 111 324 145 344 171 321 201 332 231 307 255 300 290 275 309 269 347 246 374 230 424 206 452 183 411 172 375 151 348 137 314 111 287 104 251 80 226 88 192 61 163 76 128 62 96 Z" fill="#d6c69c" opacity=".10" filter="url(#soft)" transform="translate(0 8)"/>
      <path d="M93 44 L145 27 185 43 219 35 247 62 285 68 306 101 337 111 324 145 344 171 321 201 332 231 307 255 300 290 275 309 269 347 246 374 230 424 206 452 183 411 172 375 151 348 137 314 111 287 104 251 80 226 88 192 61 163 76 128 62 96 Z" fill="url(#land)" stroke="#f0dfb8" strokeWidth="2.5" strokeLinejoin="round"/>
      <path d="M100 84 Q175 115 285 91 M82 164 Q170 194 322 167 M112 251 Q191 277 301 241 M148 328 Q206 349 273 313" fill="none" stroke="#f4e6c7" strokeOpacity=".32" strokeWidth="1.2" strokeDasharray="4 8"/>
      <path d="M54 94 Q155 70 337 112 M46 205 Q178 178 357 214 M70 326 Q184 300 324 352" fill="none" stroke="#f4e6c7" strokeOpacity=".22" strokeWidth="1" strokeDasharray="2 7"/>
      <text x="208" y="245" textAnchor="middle" fill="#344c3d" fontSize="18" letterSpacing="7" fontWeight="700" opacity=".7">INDIA</text>
    </svg>
    {places.map((place) => <button key={place.name} className={`map-pin ${selected === place.name ? 'active' : ''} ${place.name === 'Chandigarh' ? 'pilot' : ''}`} style={{ left: `${place.x}%`, top: `${place.y}%` }} onClick={() => onSelect(place.name)} aria-label={`Select ${place.name}`}>
      <span className="pin-dot" /><span className="pin-label">{place.name}</span>
    </button>)}
    <div className="map-compass"><span>N</span><b>✳</b></div>
    <div className="map-scale">SCHEMATIC CITY EXPLORER <span>•</span> NOT FOR NAVIGATION</div>
  </div>;
}

function App() {
  const [activeView, setActiveView] = useState<'explore' | 'discover' | 'about'>('explore');
  const [selected, setSelected] = useState('Chandigarh');
  const [layer, setLayer] = useState<Layer>('vegetation');
  const [year, setYear] = useState(2024);
  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const [compare, setCompare] = useState(false);
  const [search, setSearch] = useState('');
  const place = places.find((p) => p.name === selected) ?? places[0];
  const filteredPlaces = useMemo(() => places.filter((p) => p.name.toLowerCase().includes(search.toLowerCase())), [search]);

  const enterExplore = () => { setActiveView('explore'); document.getElementById('explorer')?.scrollIntoView({ behavior: 'smooth' }); };

  return <div className="site-shell">
    <header className="topbar">
      <a className="brand" href="#top" onClick={() => setActiveView('explore')}><span className="brand-mark">◎</span><span>EARTH<span className="brand-light">SIGNAL</span></span></a>
      <nav className="main-nav" aria-label="Main navigation">
        <button className={activeView === 'explore' ? 'nav-active' : ''} onClick={() => { setActiveView('explore'); enterExplore(); }}>Explore</button>
        <button className={activeView === 'discover' ? 'nav-active' : ''} onClick={() => { setActiveView('discover'); document.getElementById('discover')?.scrollIntoView({ behavior: 'smooth' }); }}>Discover</button>
        <button className={activeView === 'about' ? 'nav-active' : ''} onClick={() => { setActiveView('about'); document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' }); }}>About the science</button>
      </nav>
      <a className="top-cta" href="#explorer" onClick={() => setActiveView('explore')}>Open the atlas <Arrow diagonal /></a>
    </header>

    <main id="top">
      <section className="hero-section">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> AN OPEN ATLAS OF A CHANGING INDIA</div>
          <h1>The planet is<br/><em>always telling</em><br/>us something.</h1>
          <p className="hero-lede">Earth Signal turns satellite observations into stories you can explore. Follow the living patterns of our cities, question what changed, and see the evidence behind every signal.</p>
          <div className="hero-actions"><button className="button-primary" onClick={enterExplore}>Explore the atlas <Arrow /></button><a className="text-link" href="#about">How it works <Arrow diagonal /></a></div>
          <div className="hero-footnote"><span className="live-dot" /> BUILT FOR CURIOSITY. GROUNDED IN EVIDENCE.</div>
        </div>
        <div className="hero-visual" aria-label="Illustration of Earth surrounded by satellite observation paths">
          <div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/>
          <div className="earth-glow"/><div className="earth-ball"><div className="earth-texture"/><div className="earth-clouds"/></div>
          <div className="satellite satellite-one">✦</div><div className="satellite satellite-two">✧</div>
          <div className="orbit-label label-top">OBSERVE <span>01</span></div><div className="orbit-label label-right">INTERPRET <span>02</span></div><div className="orbit-label label-bottom">UNDERSTAND <span>03</span></div>
          <div className="hero-coordinate">30°44′N<br/>76°47′E</div>
          <div className="hero-note"><span className="note-icon">↗</span><span><b>One planet.</b><br/>A million changing stories.</span></div>
        </div>
        <div className="hero-bottom"><span>01 / A NEW WAY TO LOOK CLOSER</span><span>SCROLL TO EXPLORE <span className="scroll-mark">↓</span></span></div>
      </section>

      <section className="intro-strip"><p>FROM ORBIT TO YOUR NEIGHBOURHOOD</p><div className="strip-words"><span>VEGETATION</span><i>✳</i><span>LAND SURFACE</span><i>✳</i><span>CLIMATE</span><i>✳</i><span>CHANGE OVER TIME</span></div></section>

      <section className="explorer-section" id="explorer">
        <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> THE LIVING ATLAS <span className="section-index">01</span></div><h2>Start with a place.<br/><em>Follow its signal.</em></h2></div><p className="section-aside">Choose a city, switch the lens, and explore what we can—and cannot—learn from Earth observation data.</p></div>
        <div className="explorer-frame">
          <div className="explorer-topline"><div className="atlas-title"><span className="atlas-symbol">⌖</span><div><b>INDIA FIELD ATLAS</b><small>GEOGRAPHIC OVERVIEW · EARLY ACCESS</small></div></div><div className="atlas-status"><span className="status-dot"/> DATA ENGINE IN DEVELOPMENT</div></div>
          <div className="explorer-body">
            <aside className="explorer-sidebar">
              <label className="field-label" htmlFor="place-search">FIND A PLACE</label>
              <div className="search-wrap"><span>⌕</span><input id="place-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search Indian cities" /></div>
              <div className="place-list">{filteredPlaces.map((p) => <button key={p.name} className={`place-option ${selected === p.name ? 'selected' : ''}`} onClick={() => setSelected(p.name)}><span className="place-marker">{p.name === 'Chandigarh' ? '✳' : '·'}</span><span>{p.name}<small>{p.region}</small></span><Arrow /></button>)}{filteredPlaces.length === 0 && <p className="empty-search">No matching city in this starter atlas.</p>}</div>
              <div className="sidebar-note"><span>✳</span><p><b>Our first field study</b><br/>Chandigarh is the pilot area while we validate source data and boundaries.</p></div>
            </aside>
            <div className="map-stage"><div className="map-toolbar"><div><span className="tiny-label">REGION</span><b>INDIA</b></div><div className="map-toolbar-right"><span className="tiny-label">VIEW</span><b>OVERVIEW</b><button title="Reset selected city" onClick={() => setSelected('Chandigarh')}>↺</button></div></div>
              <IndiaMap selected={selected} onSelect={setSelected} layer={layer}/>
              <div className="map-legend"><span><i className="legend-pilot"/> PILOT AREA</span><span><i className="legend-city"/> CITY INDEX</span></div>
            </div>
            <aside className="detail-panel">
              <div className="detail-top"><span className="tiny-label">SELECTED LOCATION</span><span className="location-number">ES / 001</span></div>
              <h3>{place.name}<span className="detail-star">✳</span></h3><p className="place-region">{place.region}</p>
              <div className="detail-rule"/><div className="field-label">ENVIRONMENTAL LENS</div>
              <div className="layer-switcher">{(Object.keys(layerInfo) as Layer[]).map((key) => <button key={key} className={layer === key ? 'layer-active' : ''} onClick={() => setLayer(key)}><span>{layerInfo[key].short}</span>{layerInfo[key].label}{layer === key && <b>✓</b>}</button>)}</div>
              <div className="signal-card"><div className="signal-card-head"><span className="tiny-label">SIGNAL STATUS</span><span className="status-pill">NOT YET MEASURED</span></div><div className="signal-placeholder"><span className="placeholder-spark">✳</span><div><b>Awaiting observations</b><small>We won't invent a reading where no validated dataset exists.</small></div></div><p className="layer-detail">{layerInfo[layer].detail}</p></div>
              <div className="detail-bottom"><div><span className="tiny-label">DATA AVAILABILITY</span><b>{layerInfo[layer].status}</b></div><button className="evidence-button" onClick={() => setEvidenceOpen(true)}>View methodology <Arrow diagonal /></button></div>
            </aside>
          </div>
          <div className="timeline-bar"><div className="timeline-label"><span className="tiny-label">TIME EXPLORER</span><b>{year}</b></div><div className="timeline-control"><input aria-label="Select year" type="range" min="2017" max="2025" value={year} onChange={(e) => setYear(Number(e.target.value))}/><div className="timeline-years"><span>2017</span><span>2019</span><span>2021</span><span>2023</span><span>2025</span></div></div><span className="timeline-unavailable">PERIOD SELECTION PREVIEW · NO OBSERVATIONS LOADED</span></div>
        </div>
        <div className="explorer-caption"><span>FIG. 01 — AN INTERACTIVE INDEX OF PLACES</span><span>Map artwork is schematic, not a boundary dataset.</span></div>
      </section>

      <section className="discover-section" id="discover">
        <div className="discover-intro"><div className="eyebrow"><span className="eyebrow-line"/> WHAT WE'RE BUILDING <span className="section-index">02</span></div><h2>Not just a map.<br/><em>A way to notice.</em></h2><p>Environmental data can feel distant. Earth Signal brings it closer—without flattening the complexity or hiding the uncertainty.</p></div>
        <div className="feature-grid">
          <article className="feature-card feature-large"><div className="feature-illustration terrain-illustration"><div className="terrain-sun"/><div className="terrain-line line-a"/><div className="terrain-line line-b"/><div className="terrain-line line-c"/><span className="illus-tag">01 / OBSERVE</span></div><div className="feature-copy"><span>EXPLORE THE LAYERS</span><h3>See the city<br/>from another angle.</h3><p>Move between environmental lenses and discover what satellite observations can reveal about a place.</p></div></article>
          <article className="feature-card"><div className="feature-illustration time-illustration"><div className="time-orbit"><span>2017</span><b>↗</b><span>2025</span></div><div className="time-dots">··············</div><span className="illus-tag">02 / COMPARE</span></div><div className="feature-copy"><span>TRAVEL THROUGH TIME</span><h3>Change has<br/>a timeline.</h3><p>Compare consistent observation periods and see where the record has gaps.</p></div></article>
          <article className="feature-card"><div className="feature-illustration signal-illustration"><div className="signal-rings"><i/><i/><i/><b>!</b></div><span className="illus-tag">03 / INVESTIGATE</span></div><div className="feature-copy"><span>FOLLOW AN UNUSUAL SIGNAL</span><h3>Curiosity, meet<br/>evidence.</h3><p>Investigate patterns with transparent methods. An anomaly is a clue—not a conclusion.</p></div></article>
        </div>
      </section>

      <section className="science-section" id="about"><div className="science-art"><div className="science-orbit orbit-a"/><div className="science-orbit orbit-b"/><div className="science-core">ES<span>✳</span></div><div className="science-label label-a">SOURCE</div><div className="science-label label-b">METHOD</div><div className="science-label label-c">LIMITS</div></div><div className="science-copy"><div className="eyebrow"><span className="eyebrow-line"/> THE SCIENCE BEHIND THE SIGNAL <span className="section-index">03</span></div><h2>Beautiful visuals.<br/><em>Uncompromising receipts.</em></h2><p>Every finding should come with its source, observation date, spatial resolution, processing method, quality flags and uncertainty. If the data cannot support an answer, Earth Signal should say so.</p><button className="button-dark" onClick={() => setEvidenceOpen(true)}>See our data principles <Arrow /></button><div className="science-principles"><span><b>01</b> Traceable sources</span><span><b>02</b> Honest data gaps</span><span><b>03</b> No invented certainty</span></div></div></section>

      <section className="closing-section"><div className="closing-orb">✳</div><div className="eyebrow"><span className="eyebrow-line"/> THE FIRST SIGNAL STARTS HERE</div><h2>Look closer.<br/><em>Understand more.</em></h2><button className="button-primary" onClick={enterExplore}>Return to the atlas <Arrow /></button><p>EARTH SIGNAL · AN INDEPENDENT LEARNING PROJECT</p></section>
    </main>

    <footer className="footer"><a className="brand" href="#top"><span className="brand-mark">◎</span><span>EARTH<span className="brand-light">SIGNAL</span></span></a><span>READ THE LIVING PLANET.</span><span>BUILT WITH CURIOSITY & CARE · 2026</span></footer>

    {evidenceOpen && <div className="modal-backdrop" role="presentation" onClick={() => setEvidenceOpen(false)}><section className="evidence-modal" role="dialog" aria-modal="true" aria-labelledby="evidence-title" onClick={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setEvidenceOpen(false)} aria-label="Close">×</button><div className="eyebrow"><span className="eyebrow-line"/> METHODS NOTE</div><h2 id="evidence-title">What this layer can tell us.</h2><p>{layerInfo[layer].detail}</p><div className="method-row"><span>Selected lens</span><b>{layerInfo[layer].label} ({layerInfo[layer].short})</b></div><div className="method-row"><span>Current status</span><b>{layerInfo[layer].status}</b></div><div className="method-row"><span>Study location</span><b>{place.name}</b></div><div className="method-note">The current build contains the NDVI calculation function and unit tests, but no source satellite scenes or validated city observations. The timeline and map are interactive interface previews—not measured environmental results.</div><button className="button-dark modal-done" onClick={() => setEvidenceOpen(false)}>Back to exploring <Arrow /></button></section></div>}
    {compare && <div className="compare-toast">Comparison mode is planned for the next build. <button onClick={() => setCompare(false)}>Dismiss</button></div>}
    <button className="compare-fab" onClick={() => setCompare(true)} title="Compare places">⇄ <span>Compare</span></button>
  </div>;
}

export default App;
